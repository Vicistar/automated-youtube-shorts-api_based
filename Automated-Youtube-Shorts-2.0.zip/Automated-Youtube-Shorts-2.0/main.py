import os
import logging
from modules.instagram_scraper import main as scrape_instagram
from modules.video_compiler import compile_videos
from modules.youtube_uploader import authenticate_youtube, upload_video

# Logging configuration
logging.basicConfig(filename="logs/main.log", level=logging.INFO)

def main():
    try:
        logging.info("Starting pipeline...")

        # Step 1: Scrape videos from Instagram
        logging.info("Scraping videos from Instagram...")
        scrape_instagram()

        # Step 2: Compile videos
        logging.info("Compiling videos...")
        input_folder = "data/scraped_videos"
        output_file = "data/compiled_videos/compiled.mp4"
        compile_videos(input_folder, output_file)

        # Step 3: Upload video to YouTube
        logging.info("Uploading video to YouTube...")
        youtube = authenticate_youtube()
        upload_video(
            youtube,
            output_file,
            "Daily Meme Compilation",
            "Enjoy these hilarious memes!",
            ["memes", "funny", "compilation"]
        )

        logging.info("Pipeline completed successfully!")
    except Exception as e:
        logging.error(f"An error occurred: {e}")

if __name__ == "__main__":
    main()
