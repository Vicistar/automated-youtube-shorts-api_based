import os
import asyncio
import aiohttp
import json
import logging
from pathlib import Path

# Logging configuration
logging.basicConfig(filename="logs/scraper.log", level=logging.INFO)

INSTAGRAM_API_URL = "https://graph.instagram.com/"
# ACCESS_TOKEN = json.load(open("config/instagram_config.json"))["access_token"]
ACCESS_TOKEN = "IGQWROajc4Sk83MWlGQVVYVHFRTG1qSXhEWktyVTJ6Q2FWQWI4aHp3bzdKbEcyTXROTVktYXN0NU9ERXRTRkJ5SS1RdVduNjA2MTRNWkJyUnYzaUpicjh5VHhhVWhWQmlNWEp3WGtQQUNVaUk5RzIwcUhoRzFaZAzQZD"

async def fetch_videos(username):
    try:
        # Simulated API endpoint for demo purposes
        url = f"{INSTAGRAM_API_URL}{username}/media?fields=id,media_type,media_url&access_token={ACCESS_TOKEN}"
        async with aiohttp.ClientSession() as session:
            async with session.get(url) as response:
                data = await response.json()
                videos = [item for item in data.get("data", []) if item["media_type"] == "VIDEO"]
                save_videos(videos, username)
    except Exception as e:
        logging.error(f"Error fetching videos for {username}: {e}")

def save_videos(videos, username):
    Path(f"data/scraped_videos/{username}").mkdir(parents=True, exist_ok=True)
    for video in videos:
        video_url = video["media_url"]
        video_id = video["id"]
        file_path = f"data/scraped_videos/{username}/{video_id}.mp4"
        os.system(f"curl -o {file_path} {video_url}")

async def main():
    with open("data/usernames.txt", "r") as file:
        usernames = [line.strip() for line in file.readlines()]
    
    tasks = [fetch_videos(username) for username in usernames]
    await asyncio.gather(*tasks)

if __name__ == "__main__":
    asyncio.run(main())
