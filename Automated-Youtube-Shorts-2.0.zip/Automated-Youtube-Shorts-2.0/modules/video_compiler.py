import os
from moviepy.editor import VideoFileClip, concatenate_videoclips
import logging

logging.basicConfig(filename="logs/compiler.log", level=logging.INFO)

def compile_videos(input_folder, output_file):
    try:
        clips = []
        for file in os.listdir(input_folder):
            if file.endswith(".mp4"):
                video = VideoFileClip(os.path.join(input_folder, file)).subclip(0, 10)  # Trim to 10 seconds
                clips.append(video)
        
        final_clip = concatenate_videoclips(clips)
        final_clip.write_videofile(output_file, codec="libx264")
        logging.info(f"Compiled video saved at {output_file}")
    except Exception as e:
        logging.error(f"Error compiling videos: {e}")

if __name__ == "__main__":
    compile_videos("data/scraped_videos", "data/compiled_videos/compiled.mp4")
