import os
import json
import logging
from googleapiclient.discovery import build
from googleapiclient.http import MediaFileUpload
from google_auth_oauthlib.flow import InstalledAppFlow

logging.basicConfig(filename="logs/uploader.log", level=logging.INFO)

def authenticate_youtube():
    flow = InstalledAppFlow.from_client_secrets_file(
        "config/youtube_config.json",
        scopes=["https://www.googleapis.com/auth/youtube.upload"]
    )
    credentials = flow.run_console()
    return build("youtube", "v3", credentials=credentials)

def upload_video(youtube, file_path, title, description, tags):
    try:
        request = youtube.videos().insert(
            part="snippet,status",
            body={
                "snippet": {
                    "title": title,
                    "description": description,
                    "tags": tags,
                    "categoryId": "23"  # Comedy
                },
                "status": {
                    "privacyStatus": "public"
                }
            },
            media_body=MediaFileUpload(file_path)
        )
        response = request.execute()
        logging.info(f"Video uploaded: {response['id']}")
        os.remove(file_path)  # Delete uploaded file
    except Exception as e:
        logging.error(f"Error uploading video: {e}")

if __name__ == "__main__":
    youtube = authenticate_youtube()
    upload_video(
        youtube,
        "data/compiled_videos/compiled.mp4",
        "Daily Meme Compilation",
        "Enjoy these hilarious memes!",
        ["memes", "funny", "compilation"]
    )
